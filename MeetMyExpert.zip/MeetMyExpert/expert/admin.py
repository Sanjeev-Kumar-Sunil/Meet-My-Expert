from django.contrib import admin
from expert.models import Expert,Feedback
# Register your models here.

admin.site.register(Expert)
admin.site.register(Feedback)